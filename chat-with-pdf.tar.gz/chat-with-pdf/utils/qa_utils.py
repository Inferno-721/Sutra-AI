import openai
from typing import List

class QASystem:
    def __init__(self, api_key: str):
        openai.api_key = api_key
        
    def generate_answer(self, question: str, context: List[str]) -> str:
        prompt = f"""Based on the context provided below, answer the question.
        If the answer is not in the context, respond with "The answer is not in the provided context."

        Context:
        {' '.join(context)}

        Question: {question}
        """
        
        response = openai.chat.completions.create(  # Updated line
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an assistant answering questions based on the provided context."},
                {"role": "user", "content": prompt}
            ],
            temperature=0,
            max_tokens=500
        )
        return response.choices[0].message.content
